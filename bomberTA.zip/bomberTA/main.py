from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import NumericProperty, ReferenceListProperty,\
    ObjectProperty
from kivy.core.window import Window
from kivy.vector import Vector
from kivy.clock import Clock
from random import randint
import time
from kivy.graphics import Color, Ellipse, Rectangle
import math
from kivy.core.window import Window
Window.size = (800, 600)

class BomberW(Widget):
    pass

class Block(Widget):
   pass

class BomberGame(Widget):
    bomberman = ObjectProperty(None)
    level = ObjectProperty(None)
    isBombDraggable=True;
    levelBomb=[]
    enCoursBombe=[]
    levelBlock=[(randint(0,5),randint(0,5)) for k in range(randint(5,15))]
    levelMur = [(randint(0, 5), randint(0, 5)) for k in range(randint(2, 8))]
    fullCoord=[]
    mort=False
    for k in range(6):
        for j in range(6):
            fullCoord.append((k,j))
    for coord in levelBlock:
        if (coord == (2,2)):
            print("On a du remove la dalle centrale")
            levelBlock.remove(coord)
    for coord in levelMur:
        if (coord == (2,2)):
            print("On a du remove la dalle centrale")
            levelMur.remove(coord)

    def drawGrid(self):
        self.canvas.children.clear()
        for coord in self.fullCoord:
            with self.canvas:
                Color(1, 1, 1, 1, mode='rgba')
                Rectangle(pos=(Window.width/5*coord[0], Window.height/5*coord[1]), size=(Window.width/5-5, Window.height/5-5))

        for coord in self.levelBlock:
            with self.canvas:
                Color(0, 1, 0, 1, mode='rgba')
                Rectangle(pos=(Window.width/5*coord[0], Window.height/5*coord[1]), size=(Window.width/5-5, Window.height/5-5))
        for coord in self.levelMur:
            with self.canvas:
                Color(0, 0, 0, 1, mode='rgba')
                Rectangle(pos=(Window.width/5*coord[0], Window.height/5*coord[1]), size=(Window.width/5-5, Window.height/5-5))
        for i in range(6):
            for j in range(6):
                if (i,j) not in self.levelMur+self.levelBlock:
                    with self.canvas:
                        Color(1, 1, 1, 1, mode='rgba')
                        Rectangle(pos=(Window.width / 5 * coord[0], Window.height / 5 * coord[1]),
                                  size=(Window.width / 5 - 5, Window.height / 5 - 5))
        for bomb in self.enCoursBombe:
            if bomb["color"]=="black":
                with self.canvas:
                    Color(0, 0, 0, .5, mode='rgba')
                    Ellipse(pos=(bomb["coord"][0] - 150, bomb["coord"][1] - 150), size=(300, 300))
            else:
                with self.canvas:
                    Color(1, 0, 0, .5, mode='rgba')
                    Ellipse(pos=(bomb["coord"][0] - 150, bomb["coord"][1] - 150), size=(300, 300))
        if not self.mort:
            with self.canvas:
                Color(0,0,1,1, mode='rgba')
                Ellipse(pos=(self.bomberman.center_x-40, self.bomberman.center_y-40),
                          size=(80,80))

    def on_touch_move(self, touch):
        if touch.button == 'right' and self.isBombDraggable:
            isRightCliquable=True
            if math.sqrt((self.bomberman.center_x - touch.x)**2 + (self.bomberman.center_y - touch.y)**2)>40:
                isRightCliquable = False;
            if isRightCliquable:
                print("ON POSE UNE BOMBE")
                self.isBombDraggable = False;
                self.levelBomb.append({"coord":(touch.x, touch.y), "time":time.time()})
            return;
        allowed=True;
        if math.sqrt((self.bomberman.center_x - touch.x)**2 + (self.bomberman.center_y - touch.y)**2)>math.inf:
            allowed=False;
        for coord in self.levelBlock+self.levelMur:
            if (touch.x+40>coord[0]*self.width/5 and touch.x-40<(coord[0]+1)*self.width/5 ) and (touch.y+40>coord[1]*self.height/5 and touch.y-40<(coord[1]+1)*self.height/5 ):
                allowed=False
        if not allowed:
            return;
        self.bomberman.center_x = touch.x
        self.bomberman.center_y = touch.y

    def update(self, dt):
        self.drawGrid()
        newLbomb=[]
        newenCoursBombe=[]
        for bomb in self.levelBomb:
            if time.time()<bomb["time"]+3:
                newLbomb.append(bomb)
            else:
                self.explode(bomb)
        for bomb in self.enCoursBombe:
            if time.time()<bomb["time"]+5:
                newenCoursBombe.append(bomb)
        self.levelBomb= newLbomb.copy()
        self.enCoursBombe=newenCoursBombe.copy()
        return;

    def resetBombeDelai(self, dt):
        self.isBombDraggable=True;

    def explode(self, bomb):
        print("Une bombe explose")
        for coord in self.levelBlock:
            if math.sqrt((bomb["coord"][0]-Window.width/5*(coord[0]+0.5))**2+(bomb["coord"][1]-Window.height/5*(coord[1]+0.5))**2)<230:
                print("On souhaite remove la dalle")
                self.levelBlock.remove(coord)
                with self.canvas:
                    Color(1, 1, 1, 1, mode='rgba')
                    Rectangle(pos=(Window.width / 5 * coord[0], Window.height / 5 * coord[1]),
                              size=(Window.width / 5 - 5, Window.height / 5 - 5))

        if math.sqrt((bomb["coord"][0]-self.bomberman.center_x)**2+(bomb["coord"][1]-self.bomberman.center_y)**2)<150:
            print("MORT")
            self.mort=True
            bombN=bomb
            bombN["color"]="black"
            self.enCoursBombe.append(bombN)
            with self.canvas:
                Color(0, 0, 0, .5, mode='rgba')
                Ellipse(pos=(bomb["coord"][0] - 150, bomb["coord"][1] - 150), size=(300, 300))
        else:
            bombN = bomb
            bombN["color"] = "red"
            self.enCoursBombe.append(bombN)
            with self.canvas:
                Color(1, 0, 0, .5, mode='rgba')
                Ellipse(pos=(bomb["coord"][0] - 150, bomb["coord"][1] - 150), size=(300, 300))




class BomberApp(App):
    def build(self):
        game = BomberGame()
        game.update(1)
        #game.drawGrid()
        Clock.schedule_interval(game.update, 1.0 / 60.0)
        Clock.schedule_interval(game.resetBombeDelai, 4)
        return game


if __name__ == '__main__':
    BomberApp().run()